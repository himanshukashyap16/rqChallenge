package com.reliaquest.api.controller;

import com.reliaquest.api.model.CreateEmployeeInput;
import com.reliaquest.api.model.Employee;
import com.reliaquest.api.service.EmployeeService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

// @RestController
// @RequiredArgsConstructor
// public class EmployeeController implements IEmployeeController<Employee, CreateEmployeeInput> {
//
//    private final EmployeeApiClient employeeApiClient;
//
//    @Override
//    public ResponseEntity<List<Employee>> getAllEmployees() {
//        List<Employee> employees = employeeApiClient.get("", new ParameterizedTypeReference<>() {});
//        return ResponseEntity.ok(employees);
//    }
//
//
//    @Override
//    public ResponseEntity<List<Employee>> getEmployeesByNameSearch(String searchString) {
//        List<Employee> employees = employeeApiClient.get("", new ParameterizedTypeReference<>() {});
//        List<Employee> filtered = employees.stream()
//                .filter(e -> e.getEmployee_name().contains(searchString))
//                .toList();
//        return ResponseEntity.ok(filtered);
//    }
//
//
//    @Override
//    public ResponseEntity<Employee> getEmployeeById(String id) {
//        try {
//            Employee emp = employeeApiClient.get("/{id}", new ParameterizedTypeReference<>() {}, id);
//            return ResponseEntity.ok(emp);
//        } catch (WebClientResponseException.NotFound ex) {
//            throw new EmployeeNotFoundException("Employee with ID " + id + " not found");
//        }
//    }
//
//    @Override
//    public ResponseEntity<Integer> getHighestSalaryOfEmployees() {
//        List<Employee> employees = employeeApiClient.get("", new ParameterizedTypeReference<>() {});
//
//        int highestSalary = employees.stream()
//                .mapToInt(Employee::getEmployee_salary)
//                .max()
//                .orElseThrow(() -> new IllegalStateException("No employees available"));
//        return ResponseEntity.ok(highestSalary);
//    }
//
//    @Override
//    public ResponseEntity<List<String>> getTopTenHighestEarningEmployeeNames() {
//        List<Employee> employees = employeeApiClient.get("", new ParameterizedTypeReference<>() {});
//
//        List<String> topTenEmployeeNames = employees.stream()
//                .sorted((e1, e2) -> Integer.compare(e2.getEmployee_salary(), e1.getEmployee_salary()))
//                .limit(10)
//                .map(Employee::getEmployee_name)
//                .toList();
//
//        return ResponseEntity.ok(topTenEmployeeNames);
//    }
//
//
//    @Override
//    public ResponseEntity<Employee> createEmployee(CreateEmployeeInput employeeInput) {
//        Employee createdEmployee = employeeApiClient.post("", employeeInput, new ParameterizedTypeReference<>() {});
//        return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
//    }
//
//
//    @Override
//    public ResponseEntity<String> deleteEmployeeById(String id) {
//
//        Employee employee = getEmployeeById(id).getBody();
//        DeleteEmployeeInput input = new DeleteEmployeeInput();
//        input.setName(employee.getEmployee_name());
//
//        employeeApiClient.delete("", input, new ParameterizedTypeReference<>() {});
//
//        return ResponseEntity.ok("Employee deleted successfully");
//    }
//
// }

@RestController
@RequiredArgsConstructor
public class EmployeeController implements IEmployeeController<Employee, CreateEmployeeInput> {

    private final EmployeeService employeeService;

    @Override
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    @Override
    public ResponseEntity<List<Employee>> getEmployeesByNameSearch(String searchString) {
        return ResponseEntity.ok(employeeService.searchEmployeesByName(searchString));
    }

    @Override
    public ResponseEntity<Employee> getEmployeeById(String id) {
        return ResponseEntity.ok(employeeService.getEmployeeById(id));
    }

    @Override
    public ResponseEntity<Integer> getHighestSalaryOfEmployees() {
        return ResponseEntity.ok(employeeService.getHighestSalary());
    }

    @Override
    public ResponseEntity<List<String>> getTopTenHighestEarningEmployeeNames() {
        return ResponseEntity.ok(employeeService.getTopTenHighestEarningEmployeeNames());
    }

    @Override
    public ResponseEntity<Employee> createEmployee(CreateEmployeeInput input) {
        return ResponseEntity.status(HttpStatus.CREATED).body(employeeService.createEmployee(input));
    }

    @Override
    public ResponseEntity<String> deleteEmployeeById(String id) {
        employeeService.deleteEmployeeById(id);
        return ResponseEntity.ok("Employee deleted successfully");
    }
}
