package com.reliaquest.api.client;

import com.reliaquest.api.exception.TooManyRequestsException;
import com.reliaquest.api.model.ApiResponse;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Component
@RequiredArgsConstructor
public class EmployeeApiClient {

    private final WebClient webClient;

    // Private GET method without throwing exception directly
    private <T> ApiResponse<T> getApiResponse(
            String uri, ParameterizedTypeReference<ApiResponse<T>> typeRef, Object... uriVars) {
        try {
            return webClient
                    .get()
                    .uri(uri, uriVars)
                    .retrieve()
                    .bodyToMono(typeRef)
                    .block();
        } catch (WebClientResponseException.TooManyRequests e) {
            return null;
        }
    }

    private <T> ApiResponse<T> postApiResponse(
            String uri, Object body, ParameterizedTypeReference<ApiResponse<T>> typeRef) {
        try {
            return webClient
                    .post()
                    .uri(uri)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(typeRef)
                    .block();
        }
        catch (WebClientResponseException.TooManyRequests e) {
            return null;
        }
    }

    private <T> ApiResponse<T> deleteApiResponse(
            String uri, Object body, ParameterizedTypeReference<ApiResponse<T>> typeRef) {
        return webClient
                .method(HttpMethod.DELETE)
                .uri(uri)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(typeRef)
                .block();
    }

    @Retry(name = "employee-api-retry")
    public <T> T get(String uri, ParameterizedTypeReference<ApiResponse<T>> typeRef, Object... uriVars) {
        ApiResponse<T> response = getApiResponse(uri, typeRef, uriVars);

        if (response == null) {
            throw new TooManyRequestsException("Too many requests. Please wait a moment and try again.");
        }

        return response.getData();
    }

    @Retry(name = "employee-api-retry")
    public <T> T post(String uri, Object body, ParameterizedTypeReference<ApiResponse<T>> typeRef) {
        ApiResponse<T> response = postApiResponse(uri, body, typeRef);
        if (response == null) {
            throw new TooManyRequestsException("Too many requests. Please wait a moment and try again.");
        }

        return response.getData();
    }

    public <T> T delete(String uri, Object body, ParameterizedTypeReference<ApiResponse<T>> typeRef) {
        return deleteApiResponse(uri, body, typeRef).getData();
    }
}
