package com.reliaquest.api.service;

import com.reliaquest.api.client.EmployeeApiClient;
import com.reliaquest.api.exception.EmployeeNotFoundException;
import com.reliaquest.api.model.CreateEmployeeInput;
import com.reliaquest.api.model.DeleteEmployeeInput;
import com.reliaquest.api.model.Employee;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeApiClient employeeApiClient;
    private final RedisTemplate<String, Object> redisTemplate;

    private static final String EMPLOYEE_IDS_KEY = "employee_ids";

    public List<Employee> getAllEmployees() {

        Set<Object> idSet = redisTemplate.opsForSet().members(EMPLOYEE_IDS_KEY);
        List<String> ids = idSet != null ? idSet.stream().map(Object::toString).toList() : Collections.emptyList();

        List<Employee> cachedEmployees = ids.stream()
                .map(id -> (Employee) redisTemplate.opsForValue().get(id))
                .filter(Objects::nonNull)
                .toList();

        if (!cachedEmployees.isEmpty() && cachedEmployees.size() == ids.size()) {
            return cachedEmployees;
        }

        // Fetch from API and refresh cache
        List<Employee> employees = employeeApiClient.get("", new ParameterizedTypeReference<>() {});
        redisTemplate.delete(EMPLOYEE_IDS_KEY);
        for (Employee employee : employees) {
            redisTemplate.opsForValue().set(employee.getId(), employee);
            redisTemplate.opsForSet().add(EMPLOYEE_IDS_KEY, employee.getId());
        }
        return employees;
    }

    public List<Employee> searchEmployeesByName(String searchString) {

        List<Employee> employeeList = getAllEmployees();
        if (searchString == null || searchString.isEmpty()) {
            return employeeList;
        }
        return employeeList.stream()
                .filter(e -> Optional.ofNullable(e.getEmployee_name())
                        .map(name -> name.contains(searchString))
                        .orElse(false))
                .toList();
    }

    public Employee getEmployeeById(String id) {
        Employee cachedEmployee = (Employee) redisTemplate.opsForValue().get(id);
        if (cachedEmployee != null) return cachedEmployee;

        try {
            Employee emp = employeeApiClient.get("/{id}", new ParameterizedTypeReference<>() {}, id);
            redisTemplate.opsForValue().set(emp.getId(), emp);
            redisTemplate.opsForSet().add(EMPLOYEE_IDS_KEY, emp.getId());
            return emp;
        } catch (WebClientResponseException.NotFound ex) {
            throw new EmployeeNotFoundException("Employee with ID " + id + " not found");
        }
    }

    public Integer getHighestSalary() {
        return getAllEmployees().stream()
                .map(Employee::getEmployee_salary)
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .orElseThrow(() -> new IllegalStateException("No employees available"));
    }

    public List<String> getTopTenHighestEarningEmployeeNames() {
        return getAllEmployees().stream()
                .sorted(Comparator.comparingInt(Employee::getEmployee_salary).reversed())
                .limit(10)
                .map(Employee::getEmployee_name)
                .toList();
    }

    public Employee createEmployee(CreateEmployeeInput input) {
        Employee created = employeeApiClient.post("", input, new ParameterizedTypeReference<>() {});
        redisTemplate.opsForValue().set(created.getId(), created);
        redisTemplate.opsForSet().add(EMPLOYEE_IDS_KEY, created.getId());
        return created;
    }

    public void deleteEmployeeById(String id) {
        Employee employee = getEmployeeById(id);
        DeleteEmployeeInput input = new DeleteEmployeeInput();
        input.setName(employee.getEmployee_name());

        employeeApiClient.delete("", input, new ParameterizedTypeReference<>() {});
        redisTemplate.delete(id);
        redisTemplate.opsForSet().remove(EMPLOYEE_IDS_KEY, id);
    }
}
